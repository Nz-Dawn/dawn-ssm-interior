/*
Navicat MySQL Data Transfer

Source Server         : webapp
Source Server Version : 80013
Source Host           : localhost:3306
Source Database       : interior_design

Target Server Type    : MYSQL
Target Server Version : 80013
File Encoding         : 65001

Date: 2019-06-05 14:53:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `diary_d`
-- ----------------------------
DROP TABLE IF EXISTS `diary_d`;
CREATE TABLE `diary_d` (
  `diary_id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '閺冦儴顔囩紓鏍у娇',
  `title` varchar(200) DEFAULT NULL COMMENT '日记题目',
  `introduction` varchar(500) DEFAULT NULL COMMENT '简要介绍',
  `publish_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT '发布日期',
  `browse_num` int(11) DEFAULT NULL COMMENT '阅览次数',
  `img` varchar(200) DEFAULT NULL COMMENT '图片',
  `content` text COMMENT '具体内容',
  `username` varchar(30) NOT NULL,
  PRIMARY KEY (`diary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of diary_d
-- ----------------------------
INSERT INTO `diary_d` VALUES ('12', '60平装修日记打造', '在房价很高的北京，拥有一套60平米的小蜗居已经是很了不起的事情，李先生购房后提出了装修设想。', '2019-04-29 22:29:53', '40', 'upload/images/bc5c3ac819674b2eb729e1f33d7895d5.png', '<p>购入房子后，李先生对小小的户型有着各种各样的想法，最后还是回归到舒适与创造更多可用空间的需求上，一室一厅的家，采用浅色调的硬装建材与家具，利用收纳家具和格局的改造，把小蜗居看起来宽敞。</p><p>客厅划分出宴客区域，白色布艺沙发配合圆形的原木色茶几，适合三五个至极在一起围坐聊天；也满足了一家三口的日常需求；挂墙的电视与餐桌连在一起的电视台面，让沙发与电视间的距离拉大了，观影更加舒适。</p><p>通过一系列改造以后，李先生非常满意，这也是我成功打造的又一次家居装修。欢迎大家观看、交流，共同进步。<br></p><p></p>', 'admin');
INSERT INTO `diary_d` VALUES ('13', '欧式风格', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem', '2019-04-29 21:54:24', '7', 'upload/images/603e24fc42b84f3a93e5e364e765814c.jpg;upload/images/b3ef36f8ef9643348d5611f5b5080927.jpg', '<p><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem</span><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</span></p>', 'admin');
INSERT INTO `diary_d` VALUES ('16', '意大利风格', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem', '2019-04-29 18:04:25', '4', 'upload/images/ca9faa7acfa441b48bc15dbb3e12b9c4.jpg;upload/images/78bbe4f1f6344c0598c0a5875875dbaf.jpg', '<p><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem</span><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</span></p>', 'admin');
INSERT INTO `diary_d` VALUES ('18', '独立装修新的', '第一次独立装修的体验', '2019-04-29 21:54:24', '18', 'upload/images/c21e0c977b0747e699374b6cd25ea73a.jpg', '这是第一次独立给用户设计装修 大家有喜欢这个风格的可以预约我<br>', 'yutons');
INSERT INTO `diary_d` VALUES ('19', '卧室装修', '独立装修卧室', '2019-04-29 21:53:00', '27', 'upload/images/96fb8b40a1564362afbc35adef3f653f.jpg', '第一次没有在帮助的情况下独立设计了卧室', 'yutons');
INSERT INTO `diary_d` VALUES ('20', '60平米蜗居设计', '在房价很高的年代，拥有一套60平米的小蜗居已经是了不起的事情，李先生购房后提出了装修设想。', '2019-04-29 21:51:02', null, 'upload/images/c4242419992f436c9e03fa85516183a6.png', '<p><b>购入房子后，李先生对小小的户型有着各种各样的想法，最后还是回归到舒适与创造更多可用空间的需求上，一室一厅的家，采用浅色调的硬装建材与家具，利用收纳家具和格局的改造，把小蜗居看起来宽敞。</b></p><p><b>客厅划分出宴客区域，白色布艺沙发配合圆形的原木色茶几，适合三五个至极在一起围坐聊天；也满足了一家三口的日常需求；挂墙的电视与餐桌连在一起的电视台面，让沙发与电视间的距离拉大了，观影更加舒适。<br><br>通过一系列改造以后，李先生非常满意，这也是我成功打造的又一次家居装修。欢迎大家观看、交流，共同进步。</b><br><br></p>', 'Alice');
INSERT INTO `diary_d` VALUES ('21', '阳台改造', '这是一次阳台改造', '2019-04-29 21:55:54', null, 'upload/images/c6e4f7d2b4b0442480a6769bc9032de0.jpg', '！！！！！', 'admin');
INSERT INTO `diary_d` VALUES ('22', '！！！', '！！！！！', '2019-04-29 21:56:16', null, 'upload/images/18d8b2dcec1447be8b997eb945772aa1.jpg', '！！！！！！！！', 'admin');
INSERT INTO `diary_d` VALUES ('23', '我是设计师', '测试提交', '2019-04-30 09:26:12', '1', 'upload/images/08c8027f8a4447378fb821aef18f1b71.jpg', '测试时可根据垃圾历史记录附近的垃圾垃圾收到客户发过来看即后来的发生了简历', 'lanyus');

-- ----------------------------
-- Table structure for `exchange`
-- ----------------------------
DROP TABLE IF EXISTS `exchange`;
CREATE TABLE `exchange` (
  `replyid` int(8) DEFAULT NULL,
  `restoreid` int(8) NOT NULL COMMENT '回复评论的编号',
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论编号',
  `username` varchar(30) NOT NULL COMMENT '用户姓名',
  `publish_date` datetime NOT NULL COMMENT '发表时间',
  `message` varchar(500) DEFAULT NULL COMMENT '评论内容',
  `email` varchar(50) DEFAULT NULL COMMENT '鍥炲閭',
  `images` varchar(500) DEFAULT NULL COMMENT '头像',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exchange
-- ----------------------------
INSERT INTO `exchange` VALUES (null, '12', '1', 'user', '2019-04-22 15:42:21', 'sjguagfolaoigh;oahlkjao;;gjbusgp;dkbuishmv;', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '12', '2', 'user', '2019-04-22 15:42:38', 'sjguagfolaoigh;oahlkjao;;gjbusgp;dkbuishmv;', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '13', '3', 'user', '2019-04-22 15:50:05', '库及复印件是如何谷口i可超过德国海军', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '12', '4', 'user', '2019-04-28 13:00:17', '共产主义接班人', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES ('4', '12', '5', 'user', '2019-04-28 14:15:36', '哈哈哈哈哈', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES ('4', '12', '6', 'admin', '2019-04-28 17:58:33', '其实还好', '115313100@qq.com', '/upload/images/cddff53fe32541c8aa4bfead10929bab.jpg');
INSERT INTO `exchange` VALUES ('4', '12', '7', 'admin', '2019-04-28 17:58:48', '！！', '115313100@qq.com', '/upload/images/cddff53fe32541c8aa4bfead10929bab.jpg');
INSERT INTO `exchange` VALUES ('4', '12', '8', 'admin', '2019-04-28 17:59:06', '..', '115313100@qq.com', '/upload/images/cddff53fe32541c8aa4bfead10929bab.jpg');
INSERT INTO `exchange` VALUES ('3', '13', '9', 'yutons', '2019-04-28 18:00:41', '对我的设计满意吗', '115313100@qq.com', '/upload/images/bda2f4a43b914843b48f25a4a438f20f.jpg');
INSERT INTO `exchange` VALUES ('4', '12', '10', 'yutons', '2019-04-28 18:01:09', '！！！！', '115313100@qq.com', '/upload/images/bda2f4a43b914843b48f25a4a438f20f.jpg');
INSERT INTO `exchange` VALUES ('4', '12', '11', 'yutons', '2019-04-28 18:01:19', '.....', '115313100@qq.com', '/upload/images/bda2f4a43b914843b48f25a4a438f20f.jpg');
INSERT INTO `exchange` VALUES ('4', '12', '12', 'yutons', '2019-04-28 21:51:20', '哈哈哈哈哈哈哈哈或', '115313100@qq.com', '/upload/images/bda2f4a43b914843b48f25a4a438f20f.jpg');
INSERT INTO `exchange` VALUES (null, '12', '13', 'yutons', '2019-04-28 21:52:06', '不回复', '115313100@qq.com', '/upload/images/bda2f4a43b914843b48f25a4a438f20f.jpg');
INSERT INTO `exchange` VALUES ('13', '12', '14', 'user', '2019-04-28 21:52:56', '回复', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '19', '15', 'user', '2019-04-28 22:30:10', '！！！！！！', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '16', '16', 'tiantian', '2019-04-29 18:04:25', '！！！', '123@qq.com', null);
INSERT INTO `exchange` VALUES (null, '18', '17', 'tiantian', '2019-04-29 18:05:39', '！！！！！', '123@qq.com', '/upload/images/6e181c9ab0fa459f98147aa9038424ce.jpg');
INSERT INTO `exchange` VALUES ('13', '12', '18', 'tiantian', '2019-04-29 18:06:16', '！！', '123@qq.com', '/upload/images/6e181c9ab0fa459f98147aa9038424ce.jpg');
INSERT INTO `exchange` VALUES ('17', '18', '19', 'admin', '2019-04-29 18:15:49', '感觉怎么样？', '115313100@qq.com', '/upload/images/9ceee32305f84e38bd27c34a721febad.jpg');
INSERT INTO `exchange` VALUES ('15', '19', '20', 'yutons', '2019-04-29 18:16:44', '满意吗', '115313100@qq.com', '/upload/images/5970d6345f204477b77a1c674e1761de.png');
INSERT INTO `exchange` VALUES (null, '18', '21', 'user', '2019-04-29 18:17:40', '我觉得还行', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES (null, '19', '22', 'user', '2019-04-29 21:42:55', '设计感足', '1153131@qq.com', null);
INSERT INTO `exchange` VALUES ('22', '19', '23', 'admin', '2019-04-29 21:44:39', '满意就好', '115313100@qq.com', '/upload/images/9ceee32305f84e38bd27c34a721febad.jpg');

-- ----------------------------
-- Table structure for `module_d`
-- ----------------------------
DROP TABLE IF EXISTS `module_d`;
CREATE TABLE `module_d` (
  `module_id` varchar(20) NOT NULL COMMENT '模块编号',
  `name` varchar(50) DEFAULT NULL COMMENT '模块名称',
  `parent_id` varchar(40) DEFAULT NULL COMMENT '上级模块',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注信息',
  `order_no` int(11) NOT NULL COMMENT '模块排序号',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of module_d
-- ----------------------------

-- ----------------------------
-- Table structure for `order_d`
-- ----------------------------
DROP TABLE IF EXISTS `order_d`;
CREATE TABLE `order_d` (
  `order_id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '棰勭害缂栧彿',
  `user_name` varchar(20) DEFAULT NULL COMMENT '閻劍鍩涚紓鏍у娇',
  `designer_name` varchar(20) DEFAULT NULL COMMENT '閻犱焦宕橀鍝ユ暜閸垻妞介柛?',
  `order_date` date NOT NULL COMMENT '棰勭害鏃堕棿',
  `order_content` varchar(500) DEFAULT NULL COMMENT '预约内容',
  `state` int(20) NOT NULL COMMENT '鐘舵€佷俊鎭?',
  PRIMARY KEY (`order_id`),
  KEY `fk_order_user` (`user_name`),
  KEY `fk_order_designer` (`designer_name`),
  CONSTRAINT `fk_order_designer` FOREIGN KEY (`designer_name`) REFERENCES `t_user` (`username`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_name`) REFERENCES `t_user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_d
-- ----------------------------
INSERT INTO `order_d` VALUES ('1', 'strong-eagle', 'yutons', '2019-04-01', 'keyidsnkfdasghkajsfkg;', '1');
INSERT INTO `order_d` VALUES ('3', 'user', 'yutons', '2019-04-12', '请大师设计一下', '1');
INSERT INTO `order_d` VALUES ('4', 'user', 'yutons', '2019-04-16', '请输入您要预约的内容', '1');
INSERT INTO `order_d` VALUES ('5', 'user', 'yutons', '2019-04-13', 'ahjgj', '1');
INSERT INTO `order_d` VALUES ('6', 'user', 'lanyus', '2019-04-11', '和环境莫妮卡', '0');
INSERT INTO `order_d` VALUES ('7', 'user', 'lanyus', '2019-04-13', '23566352', '0');
INSERT INTO `order_d` VALUES ('8', 'user', 'lanyus', '2019-04-02', '巨化股份', '0');

-- ----------------------------
-- Table structure for `product_d`
-- ----------------------------
DROP TABLE IF EXISTS `product_d`;
CREATE TABLE `product_d` (
  `product_id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '濞存籂鍐╂儌缂傚倹鐗曡ぐ?',
  `designer_name` varchar(20) DEFAULT NULL COMMENT '鐠佹崘顓哥敮鍫㈢椽閸?',
  `site_id` int(8) unsigned DEFAULT NULL COMMENT '闁革附澹嗛崑锝囩磽閺嵮冨▏',
  `style_id` int(8) unsigned DEFAULT NULL COMMENT '濡炲瀛╅悧鍝ョ磽閺嵮冨▏',
  `product_name` varchar(20) DEFAULT NULL COMMENT '产品名称',
  `image` varchar(500) DEFAULT NULL COMMENT '图片',
  `state` int(11) DEFAULT NULL COMMENT '状态信息',
  PRIMARY KEY (`product_id`),
  KEY `fk_product_designer` (`designer_name`),
  KEY `fk_product_site` (`site_id`),
  KEY `fk_product_style` (`style_id`),
  CONSTRAINT `fk_product_designer` FOREIGN KEY (`designer_name`) REFERENCES `t_user` (`username`),
  CONSTRAINT `fk_product_site` FOREIGN KEY (`site_id`) REFERENCES `site_d` (`site_id`),
  CONSTRAINT `fk_product_style` FOREIGN KEY (`style_id`) REFERENCES `style_d` (`style_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product_d
-- ----------------------------
INSERT INTO `product_d` VALUES ('1', 'admin', '3', '2', '产品1', 'upload/images/602b7f141c5b47d999d353ade5e9d77a.jpg;upload/images/6750b5cdf8d249b29317e7190508059d.jpg;upload/images/bbe501c9c982445ab242ad9328283241.jpg;upload/images/b74f486c82cf456e8b699b762c7a23e3.jpg', '1');
INSERT INTO `product_d` VALUES ('2', 'admin', '3', '2', '产品2', 'upload/images/f76277c0acf244bda8bc077544b40ec4.jpg;upload/images/c2203db4a64645a18fa11eef2e066a45.jpg', '1');
INSERT INTO `product_d` VALUES ('3', 'admin', '1', '2', '产品3', 'upload/images/d98c5507779b4ebb900b15d47ba6fe01.jpg;upload/images/532976b67f7748599511745fbb067267.jpg', '1');
INSERT INTO `product_d` VALUES ('4', 'yutons', '4', '2', '产品1', 'upload/images/d8bdd5d4ffa24c9cb0528a57c6642b66.jpg', '1');
INSERT INTO `product_d` VALUES ('5', 'yutons', '3', '2', '产品2', 'upload/images/d59e16c5eb8b456d9b1359b1bbfdb079.jpg;upload/images/32fa98b7f9644c008288a5a1e76db623.jpg', '1');

-- ----------------------------
-- Table structure for `site_d`
-- ----------------------------
DROP TABLE IF EXISTS `site_d`;
CREATE TABLE `site_d` (
  `site_id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '鍦扮偣缂栧彿',
  `site_name` varchar(50) DEFAULT NULL COMMENT '地点名称',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of site_d
-- ----------------------------
INSERT INTO `site_d` VALUES ('1', '俄罗斯', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem ');
INSERT INTO `site_d` VALUES ('3', '意大利', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem ');
INSERT INTO `site_d` VALUES ('4', '俄罗斯', '测试设计师添加地点');

-- ----------------------------
-- Table structure for `style_d`
-- ----------------------------
DROP TABLE IF EXISTS `style_d`;
CREATE TABLE `style_d` (
  `style_id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '椋庢牸缂栧彿',
  `style_name` varchar(50) DEFAULT NULL COMMENT '风格名称',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`style_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of style_d
-- ----------------------------
INSERT INTO `style_d` VALUES ('1', '俄罗斯风格', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis aute');
INSERT INTO `style_d` VALUES ('2', '俄罗斯风格', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem');

-- ----------------------------
-- Table structure for `t_dept`
-- ----------------------------
DROP TABLE IF EXISTS `t_dept`;
CREATE TABLE `t_dept` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `code` int(11) DEFAULT NULL COMMENT '部门code',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '部门name',
  `parantid` int(11) DEFAULT NULL COMMENT '父级部门id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=536 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='部门表';

-- ----------------------------
-- Records of t_dept
-- ----------------------------
INSERT INTO `t_dept` VALUES ('1', '1', '部门1', '0');
INSERT INTO `t_dept` VALUES ('2', '2', '部门2', '0');
INSERT INTO `t_dept` VALUES ('3', '3', '部门3', '0');

-- ----------------------------
-- Table structure for `t_permission`
-- ----------------------------
DROP TABLE IF EXISTS `t_permission`;
CREATE TABLE `t_permission` (
  `id` int(11) NOT NULL COMMENT '资源 ID',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源名称',
  `menuname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '菜单名称',
  `permission` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源权限字符串',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源 url',
  `flag` int(11) DEFAULT NULL COMMENT '是否生成菜单,0:默认不生成菜单,1:生成菜单',
  `zindex` int(11) DEFAULT NULL COMMENT '菜单排序',
  `parantid` int(11) DEFAULT NULL COMMENT '父级菜单id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='t_resource';

-- ----------------------------
-- Records of t_permission
-- ----------------------------
INSERT INTO `t_permission` VALUES ('1', '系统管理', null, 'admin:*', '/admin/**', '0', null, null);
INSERT INTO `t_permission` VALUES ('2', '系统资源', null, 'pagejump:*', '/admin/pagejump/**', null, null, null);
INSERT INTO `t_permission` VALUES ('5000', '系统设置', '系统设置', 'permission', 'permission', '1', '0', '0');
INSERT INTO `t_permission` VALUES ('5100', '个人中心', '个人中心', 'member:*', '/admin/member/**', '1', '0', '5000');
INSERT INTO `t_permission` VALUES ('5110', '个人资料', '个人资料', 'member:index', '/admin/member/index', '1', '0', '5100');
INSERT INTO `t_permission` VALUES ('5120', '密码修改', '密码修改', 'member:updatepwd', '/admin/member/updatepwd/', '1', '2', '5100');
INSERT INTO `t_permission` VALUES ('5200', '用户中心', '用户中心', 'usercenter', '/admin/user/**', '1', '1', '5000');
INSERT INTO `t_permission` VALUES ('5210', '用户列表', '用户管理', 'user:index', '/admin/user/index', '1', '0', '5200');
INSERT INTO `t_permission` VALUES ('5300', '系统权限', '系统权限', 'permissioncenter', 'permissioncenter', '1', '2', '5000');
INSERT INTO `t_permission` VALUES ('5310', '角色列表', '角色管理', 'role:index', '/admin/role/index', '1', '0', '5300');
INSERT INTO `t_permission` VALUES ('5320', '权限列表', '权限管理', 'permission:index', '/admin/permission/index', '1', '1', '5300');
INSERT INTO `t_permission` VALUES ('5330', '菜单列表', '菜单管理', 'menu:index', '/admin/menu/index', '1', '2', '5300');

-- ----------------------------
-- Table structure for `t_role`
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色表 ID',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `sn` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色字符串',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='t_role';

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '超级管理员', 'administrator', '超级管理员拥有所有权限');
INSERT INTO `t_role` VALUES ('2', '设计师', 'designer', '设计师');
INSERT INTO `t_role` VALUES ('3', '用户', 'user', '用户');

-- ----------------------------
-- Table structure for `t_role_permission`
-- ----------------------------
DROP TABLE IF EXISTS `t_role_permission`;
CREATE TABLE `t_role_permission` (
  `role_id` int(11) NOT NULL COMMENT '角色 id',
  `permission_id` int(11) NOT NULL COMMENT '资源 id',
  KEY `FK_Reference_3` (`role_id`) USING BTREE,
  KEY `FK_Reference_4` (`permission_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='t_role_resource';

-- ----------------------------
-- Records of t_role_permission
-- ----------------------------
INSERT INTO `t_role_permission` VALUES ('1', '1');
INSERT INTO `t_role_permission` VALUES ('2', '1');
INSERT INTO `t_role_permission` VALUES ('2', '2');
INSERT INTO `t_role_permission` VALUES ('2', '5000');
INSERT INTO `t_role_permission` VALUES ('2', '5100');
INSERT INTO `t_role_permission` VALUES ('2', '5110');
INSERT INTO `t_role_permission` VALUES ('2', '5120');
INSERT INTO `t_role_permission` VALUES ('2', '5200');
INSERT INTO `t_role_permission` VALUES ('2', '5220');
INSERT INTO `t_role_permission` VALUES ('2', '5230');
INSERT INTO `t_role_permission` VALUES ('2', '5400');
INSERT INTO `t_role_permission` VALUES ('2', '5410');
INSERT INTO `t_role_permission` VALUES ('2', '5420');
INSERT INTO `t_role_permission` VALUES ('2', '5430');
INSERT INTO `t_role_permission` VALUES ('3', '1');
INSERT INTO `t_role_permission` VALUES ('3', '2');
INSERT INTO `t_role_permission` VALUES ('3', '5000');
INSERT INTO `t_role_permission` VALUES ('3', '5100');
INSERT INTO `t_role_permission` VALUES ('3', '5110');
INSERT INTO `t_role_permission` VALUES ('3', '5120');
INSERT INTO `t_role_permission` VALUES ('3', '5200');
INSERT INTO `t_role_permission` VALUES ('3', '5230');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '鐢ㄦ埛 ID',
  `dept_id` int(11) DEFAULT NULL COMMENT '部门id',
  `staffname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工姓名',
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工工号',
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `status` int(11) NOT NULL COMMENT '状态:0 禁用,1 启用',
  `telephone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `register_date` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `genter` varchar(10) DEFAULT NULL,
  `real_name` varchar(30) DEFAULT NULL,
  `images` varchar(500) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`,`username`),
  KEY `FK_Reference_7` (`dept_id`) USING BTREE,
  KEY `username` (`username`),
  KEY `username_2` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户&推送人员表';

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '1', 'admin', 'admin', '53f139e187e60f8376343990737b8fec', '1', '74251313513', '1153131@qq.com', '2019-04-28 12:30:47', 'man', '张三', '/upload/images/cddff53fe32541c8aa4bfead10929bab.jpg', '我是超级管理员');
INSERT INTO `t_user` VALUES ('2', '2', 'yutons', 'yutons', '650ce2fecc42ba4d47d9fa0ad0c475c8', '1', '4', '4', '2019-04-30 00:00:00', 'woman', 'Hnana', '/upload/images/21571c184bef436183f34492c0eed7dd.jpg', '我是设计师');
INSERT INTO `t_user` VALUES ('3', '3', 'user', 'user', '2f2adc2fe65335edc3f8a9d996899fd5', '1', '000', '1153131@qq.com', '2019-04-28 21:46:52', 'man', '狗子', null, '哈哈哈哈哈哈哈');
INSERT INTO `t_user` VALUES ('5', '1', 'Strong-eagle', 'strong-eagle', 'ae20bb71a7338675bd708feddf6267ba', '1', '451323', '139@154.com', '2019-04-28 12:30:52', 'woman', 'Kadis', '/upload/images/edab6ce2c4ee419eb88cfe82653b95ca.jpg', '我是设计师哈哈哈');
INSERT INTO `t_user` VALUES ('6', '3', 'lanyu', 'lanyus', '734c2c9287c194dd6694afa48caace58', '1', '5163623532', '932431212@139.com', '2019-04-30 09:19:31', 'man', 'jackson', '/upload/images/c71f35279a834d40ae9e14aac07a81ad.jpg', 'smdkgl ');
INSERT INTO `t_user` VALUES ('7', '3', 'hhhh', 'hhhh', 'a4b87c82345948d9240e113aee7a07e1', '1', null, null, '2019-04-29 00:00:00', null, null, null, null);
INSERT INTO `t_user` VALUES ('8', '3', 'nike', 'nike', '926cc08b1533c32db68fd3300eeaead8', '1', '', '', '2019-04-30 08:12:57', '', '', null, '');
INSERT INTO `t_user` VALUES ('9', '3', 'jack', 'jack', 'afb24f51623f36e91df5443b151b5353', '1', null, null, '2019-04-30 08:42:52', null, null, null, null);
INSERT INTO `t_user` VALUES ('10', '3', 'Andy', 'Andy', '35daea67f2b5e311de0bd93c0535cf3c', '1', null, null, '2019-04-30 00:00:00', null, null, null, null);
INSERT INTO `t_user` VALUES ('11', '3', 'super', 'super', '2b62eb15bbba1d660749a82e510c1997', '1', null, null, '2019-04-30 00:00:00', null, null, null, null);
INSERT INTO `t_user` VALUES ('12', '3', 'gojs', 'gojs', '3c66b4d85819b971c23385ee0aacf4f3', '1', null, null, '2019-04-30 00:00:00', null, null, null, null);

-- ----------------------------
-- Table structure for `t_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_role`;
CREATE TABLE `t_user_role` (
  `user_id` int(11) NOT NULL COMMENT '用户 id',
  `role_id` int(11) NOT NULL COMMENT '角色 id',
  KEY `FK_Reference_5` (`role_id`) USING BTREE,
  KEY `FK_Reference_6` (`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='t_user_role';

-- ----------------------------
-- Records of t_user_role
-- ----------------------------
INSERT INTO `t_user_role` VALUES ('5', '2');
INSERT INTO `t_user_role` VALUES ('1', '1');
INSERT INTO `t_user_role` VALUES ('3', '3');
INSERT INTO `t_user_role` VALUES ('7', '3');
INSERT INTO `t_user_role` VALUES ('8', '3');
INSERT INTO `t_user_role` VALUES ('9', '3');
INSERT INTO `t_user_role` VALUES ('10', '3');
INSERT INTO `t_user_role` VALUES ('11', '3');
INSERT INTO `t_user_role` VALUES ('12', '3');
INSERT INTO `t_user_role` VALUES ('2', '3');
INSERT INTO `t_user_role` VALUES ('6', '2');

-- ----------------------------
-- View structure for `view_permission_user`
-- ----------------------------
DROP VIEW IF EXISTS `view_permission_user`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`` SQL SECURITY DEFINER VIEW `view_permission_user` AS select `t_permission`.`id` AS `id`,`t_permission`.`name` AS `name`,`t_permission`.`menuname` AS `menuname`,`t_permission`.`permission` AS `permission`,`t_permission`.`url` AS `url`,`t_permission`.`flag` AS `flag`,`t_permission`.`zindex` AS `zindex`,`t_permission`.`parantid` AS `parantid`,`t_user_role`.`user_id` AS `userid` from ((`t_user_role` left join `t_role_permission` on((`t_user_role`.`role_id` = `t_role_permission`.`role_id`))) left join `t_permission` on((`t_role_permission`.`permission_id` = `t_permission`.`id`))) ;

-- ----------------------------
-- View structure for `view_role_permission`
-- ----------------------------
DROP VIEW IF EXISTS `view_role_permission`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`` SQL SECURITY DEFINER VIEW `view_role_permission` AS select `t_role`.`id` AS `id`,`t_role`.`name` AS `name`,`t_role`.`sn` AS `sn`,`t_permission`.`id` AS `permissionId`,`t_permission`.`name` AS `permissionname`,`t_permission`.`menuname` AS `menuname`,`t_permission`.`permission` AS `permission`,`t_permission`.`url` AS `url`,`t_permission`.`flag` AS `flag`,`t_permission`.`zindex` AS `zindex`,`t_permission`.`parantid` AS `parantid` from ((`t_role` left join `t_role_permission` on((`t_role`.`id` = `t_role_permission`.`role_id`))) left join `t_permission` on((`t_role_permission`.`permission_id` = `t_permission`.`id`))) ;

-- ----------------------------
-- View structure for `view_role_user`
-- ----------------------------
DROP VIEW IF EXISTS `view_role_user`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`` SQL SECURITY DEFINER VIEW `view_role_user` AS select distinct `t_role`.`id` AS `id`,`t_role`.`name` AS `name`,`t_role`.`sn` AS `sn`,`t_user_role`.`user_id` AS `user_id` from (`t_user_role` left join `t_role` on((`t_role`.`id` = `t_user_role`.`role_id`))) ;

-- ----------------------------
-- View structure for `view_user_dept_role`
-- ----------------------------
DROP VIEW IF EXISTS `view_user_dept_role`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`` SQL SECURITY DEFINER VIEW `view_user_dept_role` AS select `t_user`.`id` AS `id`,`t_user`.`dept_id` AS `dept_id`,`t_user`.`staffname` AS `staffname`,`t_user`.`username` AS `username`,`t_user`.`password` AS `password`,`t_user`.`status` AS `status`,`t_user`.`telephone` AS `telephone`,`t_user`.`email` AS `email`,`t_user`.`register_date` AS `register_date`,`t_user`.`genter` AS `genter`,`t_user`.`real_name` AS `real_name`,`t_user`.`images` AS `images`,`t_user`.`remark` AS `remark`,`t_dept`.`name` AS `deptname`,`t_role`.`name` AS `rolename`,`t_role`.`id` AS `roleId`,`t_dept`.`id` AS `deptId` from (((`t_user` left join `t_dept` on((`t_user`.`dept_id` = `t_dept`.`id`))) left join `t_user_role` on((`t_user`.`id` = `t_user_role`.`user_id`))) left join `t_role` on((`t_user_role`.`role_id` = `t_role`.`id`))) ;
