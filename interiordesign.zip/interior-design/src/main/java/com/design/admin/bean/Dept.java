package com.design.admin.bean;

import java.io.Serializable;


public class Dept extends PageBean implements Serializable {
	
    private static final long serialVersionUID = 1L;
    
    /**
     * 部门ID
     */
    private Integer id;
    
    /**
     * 部门代码
     */
    private String code;
    
    /**
     * 部门名称
     */
    private String name;
    
    /**
     * 部门父级ID
     */
    private Integer parantid;
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getParantid() {
		return parantid;
	}
	public void setParantid(Integer parantid) {
		this.parantid = parantid;
	}
	
	@Override
	public String toString() {
		return "Dept [id=" + id + ", code=" + code + ", name=" + name + ", parantid=" + parantid + "]";
	}
}
