package com.design.admin.bean;


import java.io.Serializable;


public class Role extends PageBean implements Serializable{
	
    private static final long serialVersionUID = 1L;
    
    /**
     * ID
     */
    private Integer id;
    
    /**
     * 角色ID
     */
    private Integer roleId;
    
    /**
     * 角色名
     */
    private String name;
    
    /**
     * 角色字符串
     */
    private String sn;
    
    /**
     * 备注
     */
    private String remark;
    
    /**
     * 角色拥有的权限
     */
    private String permission;
    
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	
	
	@Override
	public String toString() {
		return "Role [id=" + id + ", roleId=" + roleId + ", name=" + name + ", sn=" + sn + ", remark=" + remark
				+ ", permission=" + permission + "]";
	}
}
