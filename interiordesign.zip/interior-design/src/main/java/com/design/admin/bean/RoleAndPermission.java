package com.design.admin.bean;

public class RoleAndPermission {
	
    /**
     * 角色ID
     */
    private Integer roleId;
    
    /**
     * 权限ID
     */
    private Integer permissionId;
    
    
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getPermissionId() {
		return permissionId;
	}
	public void setPermissionId(Integer permissionId) {
		this.permissionId = permissionId;
	}
	
	
	@Override
	public String toString() {
		return "RoleAndPermission [roleId=" + roleId + ", permissionId=" + permissionId + "]";
	}
}
