package com.design.admin.dao;

import com.design.admin.bean.Dept;

import java.util.List;


public interface DeptDao {
    /**
     * 获取部门列表
     * @return
     */
    List<Dept> selectDepts();
}
