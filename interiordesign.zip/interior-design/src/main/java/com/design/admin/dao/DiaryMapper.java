package com.design.admin.dao;

import com.design.admin.bean.Diary;

import java.util.List;

public interface DiaryMapper {
    int deleteByPrimaryKey(Integer diaryId);

    int insert(Diary record);

    int insertSelective(Diary record);

    Diary selectByPrimaryKey(Integer diaryId);

    int updateByPrimaryKeySelective(Diary record);

    int updateImage(String imageurl);

    int updateByPrimaryKeyWithBLOBs(Diary record);

    int updateByPrimaryKey(Diary record);

    int updateBrowseNumByPrimaryKey(Diary record);

    List<Diary> selectAllDiary();

    List<Diary> selectDiaryByUserName(String username);
}