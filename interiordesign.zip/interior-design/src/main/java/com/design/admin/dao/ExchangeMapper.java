package com.design.admin.dao;

import com.design.admin.bean.Exchange;

import java.util.List;

public interface ExchangeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Exchange record);

    int insertSelective(Exchange record);

    Exchange selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Exchange record);

    int updateByPrimaryKey(Exchange record);

    List<Exchange> selectAllExcahnge();

    List<Exchange>selectExchangeByRestoreId(Integer restoreid);
}