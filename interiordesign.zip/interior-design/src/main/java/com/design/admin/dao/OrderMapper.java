package com.design.admin.dao;

import com.design.admin.bean.Order;

import java.util.List;

public interface OrderMapper {
    int deleteByPrimaryKey(Integer orderId);

    int insert(Order record);

    int insertSelective(Order record);

    Order selectByPrimaryKey(Integer orderId);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);

    List<Order> selectOrderByUserName(String userName);
    List<Order> selectOrderByDesignerName(String designerName);
    List<Order> selectAllOrder();
    int updateStatusById(Order order);
}