package com.design.admin.dao;

import com.design.admin.bean.Product;

import java.util.List;

public interface ProductMapper {

    List<Product>selectAllProduct();

    List<Product>selectProductByStyle(Integer styleId);

    List<Product>selectProductByDesigner(String designerName);

    int deleteByPrimaryKey(Integer productId);

    int insert(Product record);

    int insertSelective(Product record);

    Product selectByPrimaryKey(Integer productId);

    int updateByPrimaryKeySelective(Product record);

    int updateByPrimaryKey(Product record);

    Integer updateStatusById(Product record);
}