package com.design.admin.dao;

import com.design.admin.bean.Style;

import java.util.List;

public interface StyleMapper {
    int deleteByPrimaryKey(Integer styleId);

    int insert(Style record);

    int insertSelective(Style record);

    Style selectByPrimaryKey(Integer styleId);

    int updateByPrimaryKeySelective(Style record);

    int updateByPrimaryKey(Style record);

    public List<Style> selectAllStyle();
}