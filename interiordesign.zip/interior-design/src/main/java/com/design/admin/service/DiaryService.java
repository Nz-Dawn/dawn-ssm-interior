package com.design.admin.service;

import com.design.admin.bean.Diary;
import com.design.admin.bean.PageResult;

import java.util.List;

public interface DiaryService {
    int deleteByPrimaryKey(Integer diaryId);

    int insert(Diary record);

    int insertSelective(Diary record);

    Diary selectByPrimaryKey(Integer diaryId);

    int updateByPrimaryKeySelective(Diary record);

    int updateByPrimaryKeyWithBLOBs(Diary record);

    int updateByPrimaryKey(Diary record);

    List<Diary> selectAllDiary();

    PageResult selectDiaryPage(Diary diary);

    List<Diary> selectDiaryByUserName(String username);

    int updateBrowseNumByPrimaryKey(Diary record);
}
