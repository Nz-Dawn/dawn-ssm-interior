package com.design.admin.service;

import com.design.admin.bean.Order;
import com.design.admin.bean.PageResult;

public interface OrderService {
    int deleteByPrimaryKey(Integer orderId);

    int insert(Order record);

    int insertSelective(Order record);

    Order selectByPrimaryKey(Integer orderId);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);
    /**
     * 获取用户列表
     *
     * @return
     */
    PageResult selectOrderPage(Order order);
    /**
     * 更新预约表的状态
     */
    int updateStatusById(Order order);
}
