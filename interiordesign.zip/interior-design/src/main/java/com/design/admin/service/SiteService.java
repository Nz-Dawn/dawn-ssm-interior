package com.design.admin.service;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Site;

import java.util.List;

public interface SiteService {
    int deleteByPrimaryKey(Integer siteId);

    int insert(Site record);

    int insertSelective(Site record);

    Site selectByPrimaryKey(Integer siteId);

    int updateByPrimaryKeySelective(Site record);

    int updateByPrimaryKey(Site record);

    List<Site> selectAllSite();

    public PageResult selectSitePage(Site site);
}
