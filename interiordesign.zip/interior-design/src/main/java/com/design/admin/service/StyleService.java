package com.design.admin.service;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Style;

import java.util.List;

public interface StyleService {
    int deleteByPrimaryKey(Integer styleId);

    int insert(Style record);

    int insertSelective(Style record);

    Style selectByPrimaryKey(Integer styleId);

    int updateByPrimaryKeySelective(Style record);

    int updateByPrimaryKey(Style record);

    List<Style> selectAllStyle();

    public PageResult selectStylePage(Style style);
}
