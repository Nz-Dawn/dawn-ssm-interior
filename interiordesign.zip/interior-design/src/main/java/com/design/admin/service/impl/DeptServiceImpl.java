package com.design.admin.service.impl;

import com.design.admin.bean.Dept;
import com.design.admin.dao.DeptDao;
import com.design.admin.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class DeptServiceImpl implements DeptService {
	
    @Autowired
    private DeptDao deptDao;
    
    @Override
    public List<Dept> selectDepts() {
        return deptDao.selectDepts();
    }
}
