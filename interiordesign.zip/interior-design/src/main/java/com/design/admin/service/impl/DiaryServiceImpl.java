package com.design.admin.service.impl;

import com.design.admin.bean.*;
import com.design.admin.dao.DiaryMapper;
import com.design.admin.dao.RoleDao;
import com.design.admin.service.DiaryService;
import com.design.util.DateTimeUtil;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class DiaryServiceImpl implements DiaryService {
    @Autowired
    private DiaryMapper diaryMapper;

    @Autowired
    private RoleDao roleDao;
    @Override
    public int deleteByPrimaryKey(Integer diaryId) {
        return diaryMapper.deleteByPrimaryKey(diaryId);
    }

    @Override
    public int insert(Diary diary) {
        Date now=new Date();
        diary.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        User token = TokenUtil.getUser();
        diary.setUsername(token.getUsername());
        return diaryMapper.insert(diary);
    }

    @Override
    public int insertSelective(Diary diary) {
        Date now=new Date();
        diary.setPublishDate(DateTimeUtil.dateToLocalString(now));
        User token = TokenUtil.getUser();
        diary.setUsername(token.getUsername());
        return diaryMapper.insertSelective(diary);
    }

    @Override
    public Diary selectByPrimaryKey(Integer diaryId) {
        return diaryMapper.selectByPrimaryKey(diaryId);
    }

    @Override
    public int updateByPrimaryKeySelective(Diary diary) {
        User token = TokenUtil.getUser();
        diary.setUsername(token.getUsername());
        Date now=new Date();
        diary.setPublishDate(DateTimeUtil.dateToLocalString(now));
        if(diary.getDiaryId()!=null){
            Diary d=diaryMapper.selectByPrimaryKey(diary.getDiaryId());
            diary.setBrowseNum(d.getBrowseNum());
        }
        return diaryMapper.updateByPrimaryKeySelective(diary);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(Diary diary) {
        User token = TokenUtil.getUser();
        diary.setUsername(token.getUsername());
        Date now=new Date();
        if(diary.getDiaryId()!=null){
            Diary di=diaryMapper.selectByPrimaryKey(diary.getDiaryId());
            diary.setBrowseNum(di.getBrowseNum());
        }
        diary.setPublishDate(DateTimeUtil.dateToLocalString(now));
        return diaryMapper.updateByPrimaryKeyWithBLOBs(diary);
    }

    @Override
    public int updateByPrimaryKey(Diary diary) {
        if(diary.getDiaryId()!=null){
            Diary di=diaryMapper.selectByPrimaryKey(diary.getDiaryId());
            diary.setBrowseNum(di.getBrowseNum());
        }
        User token = TokenUtil.getUser();
        diary.setUsername(token.getUsername());
        Date now=new Date();
        diary.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        return diaryMapper.updateByPrimaryKey(diary);
    }

    @Override
    public List<Diary> selectAllDiary() {
       return diaryMapper.selectAllDiary();
    }

    @Override
    public PageResult selectDiaryPage(Diary diary) {
        List<Diary> data ;
        User token = TokenUtil.getUser();
        Role role = roleDao.selectRoleByUserId(token.getUserId());
        if(role.getId()==2||role.getId()==3){
            data=diaryMapper.selectDiaryByUserName(token.getUsername());
        }else{
            data=diaryMapper.selectAllDiary();
        }
        Integer count = data.size();
        PageResult orderPage = new PageResult();
        orderPage.setCount(count);
        orderPage.setData(data);

        return orderPage;
    }

    @Override
    public List<Diary> selectDiaryByUserName(String username) {
        return diaryMapper.selectDiaryByUserName(username);
    }

    @Override
    public int updateBrowseNumByPrimaryKey(Diary record) {
        return diaryMapper.updateBrowseNumByPrimaryKey(record);
    }
}
