package com.design.admin.service.impl;

import com.design.admin.bean.Exchange;
import com.design.admin.bean.User;
import com.design.admin.dao.ExchangeMapper;
import com.design.admin.service.ExchangeService;
import com.design.util.DateTimeUtil;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class ExchangeServiceImpl implements ExchangeService {
    @Autowired
    private ExchangeMapper exchangeMapper;
    @Override
    public int deleteByPrimaryKey(Integer id) {
        return exchangeMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(Exchange record) {
        Date now=new Date();
        record.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        User u=TokenUtil.getUser();
        record.setImages(u.getImages());
        return exchangeMapper.insert(record);
    }

    @Override
    public int insertSelective(Exchange record) {
        User u=TokenUtil.getUser();
        record.setImages(u.getImages());
        Date now=new Date();
        record.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        return exchangeMapper.insertSelective(record);
    }

    @Override
    public Exchange selectByPrimaryKey(Integer id) {
        return exchangeMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKeySelective(Exchange record) {
        User u=TokenUtil.getUser();
        record.setImages(u.getImages());
        Date now=new Date();
        record.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        return exchangeMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(Exchange record) {
        Date now=new Date();
        record.setPublishDate(DateTimeUtil.dateTimeToLocalString(now));
        User u=TokenUtil.getUser();
        record.setImages(u.getImages());
        return exchangeMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<Exchange> selectAllExcahnge() {
        return exchangeMapper.selectAllExcahnge();
    }

    @Override
    public List<Exchange> selectExchangeByRestoreId(Integer id) {
        return exchangeMapper.selectExchangeByRestoreId(id);
    }
}
