package com.design.admin.service.impl;


import com.design.admin.bean.Order;
import com.design.admin.bean.PageResult;
import com.design.admin.bean.Role;
import com.design.admin.bean.User;
import com.design.admin.dao.OrderMapper;
import com.design.admin.dao.RoleDao;
import com.design.admin.service.OrderService;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private RoleDao roleDao;
    @Override
    public int deleteByPrimaryKey(Integer orderId) {
        return orderMapper.deleteByPrimaryKey(orderId);
    }

    @Override
    public int insert(Order record) {
        return orderMapper.insert(record);
    }

    @Override
    public int insertSelective(Order record) {
        return orderMapper.insertSelective(record);
    }

    @Override
    public Order selectByPrimaryKey(Integer orderId) {
        return orderMapper.selectByPrimaryKey(orderId);
    }

    @Override
    public int updateByPrimaryKeySelective(Order record) {
        return orderMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(Order record) {
        return orderMapper.updateByPrimaryKey(record);
    }

    /**
     * 获取用户预约列表
     *
     * @return
     */
    @Override
    public PageResult selectOrderPage(Order order) {
        List<Order> data ;
        User token = TokenUtil.getUser();
        Role role = roleDao.selectRoleByUserId(token.getUserId());
        if(role.getId()==2){
            data=orderMapper.selectOrderByDesignerName(token.getUsername());
        }else if(role.getId()==3){
            data=orderMapper.selectOrderByUserName(token.getUsername());
        }else{
            data=orderMapper.selectAllOrder();
        }
        Integer count = data.size();
        PageResult orderPage = new PageResult();
        orderPage.setCount(count);
        orderPage.setData(data);

        return orderPage;
    }

    @Override
    public int updateStatusById(Order order) {
        int i=orderMapper.updateStatusById(order);
        return i;
    }

}
