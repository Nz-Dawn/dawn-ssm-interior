package com.design.admin.service.impl;

import com.design.admin.bean.*;
import com.design.admin.dao.ProductMapper;
import com.design.admin.dao.RoleDao;
import com.design.admin.service.ProductService;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
public class ProductServiceImpl implements ProductService
{
    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private RoleDao roleDao;

    @Override
    public List<Product> selectAllProduct() {
        return productMapper.selectAllProduct();
    }

    @Override
    public List<Product> selectProductByStyle(Integer styleId) {
        return productMapper.selectProductByStyle(styleId);
    }

    @Override
    public List<Product> selectProductByDesigner(String designerName) {
        return productMapper.selectProductByDesigner(designerName);
    }

    @Override
    public int deleteByPrimaryKey(Integer productId) {
        return productMapper.deleteByPrimaryKey(productId);
    }

    @Override
    public int insert(Product record) {
        return productMapper.insert(record);
    }

    @Override
    public int insertSelective(Product record) {
        return productMapper.insertSelective(record);
    }

    @Override
    public Product selectByPrimaryKey(Integer productId) {
        return productMapper.selectByPrimaryKey(productId);
    }

    @Override
    public int updateByPrimaryKeySelective(Product record) {
        return productMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(Product record) {
        return productMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public PageResult selectProductPage(Product product) {
        List<Product> data ;
        User token = TokenUtil.getUser();
        Role role = roleDao.selectRoleByUserId(token.getUserId());
        if(role.getId()==2){
            data=productMapper.selectProductByDesigner(token.getUsername());
        }else{
            data=productMapper.selectAllProduct();
        }
        Integer count = data.size();
        PageResult orderPage = new PageResult();
        orderPage.setCount(count);
        orderPage.setData(data);
        return orderPage;
    }

    @Override
    public Integer updateStatusById(Product product) {
        if(product.getProductId()!=null){
            Product p=productMapper.selectByPrimaryKey(product.getProductId());
        }
        return productMapper.updateStatusById(product);
    }
}
