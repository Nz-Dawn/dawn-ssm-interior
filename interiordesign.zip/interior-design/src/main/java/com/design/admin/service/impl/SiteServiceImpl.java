package com.design.admin.service.impl;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Site;
import com.design.admin.dao.SiteMapper;
import com.design.admin.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
public class SiteServiceImpl implements SiteService {
    @Autowired
    private SiteMapper siteMapper;
    @Override
    public int deleteByPrimaryKey(Integer siteId) {
        return siteMapper.deleteByPrimaryKey(siteId);
    }

    @Override
    public int insert(Site record) {
        return siteMapper.insert(record);
    }

    @Override
    public int insertSelective(Site record) {
        return siteMapper.insertSelective(record);
    }

    @Override
    public Site selectByPrimaryKey(Integer siteId) {
        return siteMapper.selectByPrimaryKey(siteId);
    }

    @Override
    public int updateByPrimaryKeySelective(Site record) {
        return siteMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(Site record) {
        return siteMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<Site> selectAllSite() {
        return siteMapper.selectAllSite();
    }

    @Override
    public PageResult selectSitePage(Site site) {
        List<Site> data =siteMapper.selectAllSite();
        Integer count = data.size();
        PageResult orderPage = new PageResult();
        orderPage.setCount(count);
        orderPage.setData(data);
        return orderPage;
    }
}
