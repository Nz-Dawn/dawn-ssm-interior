package com.design.admin.service.impl;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Style;
import com.design.admin.dao.StyleMapper;
import com.design.admin.service.StyleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StyleServiceImpl implements StyleService {

    @Autowired
    private StyleMapper styleMapper;
    @Override
    public int deleteByPrimaryKey(Integer styleId) {
        return styleMapper.deleteByPrimaryKey(styleId);
    }

    @Override
    public int insert(Style style) {
        return styleMapper.insert(style);
    }

    @Override
    public int insertSelective(Style style) {
        return styleMapper.insertSelective(style);
    }

    @Override
    public Style selectByPrimaryKey(Integer styleId) {
        return styleMapper.selectByPrimaryKey(styleId);
    }

    @Override
    public int updateByPrimaryKeySelective(Style style) {
        return styleMapper.updateByPrimaryKeySelective(style);
    }

    @Override
    public int updateByPrimaryKey(Style style) {
        return styleMapper.updateByPrimaryKey(style);
    }

    @Override
    public List<Style> selectAllStyle() {
        return styleMapper.selectAllStyle();
    }

    @Override
    public PageResult selectStylePage(Style style) {
        List<Style> data = styleMapper.selectAllStyle();
        Integer count = data.size();
        PageResult orderPage = new PageResult();
        orderPage.setCount(count);
        orderPage.setData(data);
        return orderPage;
    }
}
