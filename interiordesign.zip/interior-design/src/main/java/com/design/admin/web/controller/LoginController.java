package com.design.admin.web.controller;

import com.design.admin.bean.*;
import com.design.admin.service.*;
import com.design.util.TokenUtil;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.session.HttpServletSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;


@RequestMapping(value = "/")
@Controller
public class LoginController {
    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
    
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private DeptService deptService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        return "login";
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String register(Model model) {
        List<Role> roles=roleService.selectAllRole();
        model.addAttribute("roles",roles);
        return "register";
    }

    /**
     * 提交用户注册数据
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(User user, Model model,HttpServletRequest request) {
        String repassword=request.getParameter("repassword");
        if(user.getPassword().equals(repassword)==false){
            String msg="两次密码输入不一样，请确认";
            model.addAttribute("msg",msg);
            return "register";
        }
        if(userService.findByUserName(user.getUsername())!=null){
            String msg="该用户名也存在，请更换用户名！";
            model.addAttribute("msg",msg);
            return "register";
        }
        user.setDeptId(3);
        if(user.getRoleId()==1||user.getRoleId()==2){
            user.setStatus(0);
        }else{
            user.setStatus(1);
        }
        User add = userService.add(user);
        if (add.getUsername() == null) {
            List<Dept> depts = deptService.selectDepts();
            List<Role> roles = roleService.selectRoles();
            model.addAttribute("depts", depts);
            model.addAttribute("roles", roles);
            model.addAttribute("user", user);
            model.addAttribute("msg", "用户名已存在,请修改登录名!");
            return "register";
        } else {
            return "redirect:login";
        }
    }
    @RequestMapping(value = "/umain", method = RequestMethod.GET)
    public String customer(Model model) {
        List<User> userList = userService.selectAllUser();
        List<User> designers = new ArrayList<>();
        for (User u : userList) {
            if (u.getRoleId() == 2) {
                designers.add(u);
            }
        }
        //2.风格的信息
        List<Style> styles = styleService.selectAllStyle();
        //3.地点信息
        List<Site> sites = siteService.selectAllSite();
        model.addAttribute("styles", styles);
        model.addAttribute("designers", designers);
        model.addAttribute("sites", sites);
        return "umain/index";
    }


    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(User user, boolean rememberMe, Model model) {
        String msg = null;
        try {
            //用户登录
            user = TokenUtil.login(user, rememberMe);

        } catch (Exception e) {
            User login = userService.login(user.getUsername(), user.getPassword());
            if (login.getStatus() == 0) {
                msg = "设计师或管理员身份正在审核，请耐心等待！";
            } else {
                msg = "用户名或密码不正确";
            }
        } finally {
            if (msg == null) {
                return "redirect:/admin/pagejump/index";
            }
            model.addAttribute("msg", msg);
            return "login";
        }
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(Model model,HttpServletRequest request) {
        HttpServletSession session= (HttpServletSession) request.getSession();
        Subject subject = SecurityUtils.getSubject();
        System.out.println("session信息已经成功清除!" + session.getAttribute("user"));
        session.removeAttribute("user");
        subject.logout();
        model.addAttribute("msg", "您已经退出登录,请重新登录");
        return "login";
    }

    @RequestMapping(value = "/unAuthorization")
    public String unAuthorization() {
        return "unAuthorization";
    }

    @RequestMapping(value = "/single", method = RequestMethod.GET)
    public String single(Model model)  {
        return "umain/single";
    }
    /**
     * 查看所有设计师的日志列表
     */
    @Autowired
    private DiaryService diaryService;
    @RequestMapping(value = "/diary_list", method = RequestMethod.GET)
    public String diaryList(Model model)  {
        List<Diary> diarys=diaryService.selectAllDiary();
        List<Diary> diaries=new ArrayList();
        for (Diary d:diarys) {
            if(d.getImg()!=null) {
                String arr[] = d.getImg().split(";");
                if (arr[0] != null) {
                    d.setImg(arr[0]);
                }
                diaries.add(d);
            }
        }
        model.addAttribute("diarys",diaries);
        return "umain/diary-list";
    }
    /**
     * 跳转日志详情
     */
    @Autowired private ExchangeService exchangeService;
    @RequestMapping(value = "/diaryList/{diaryId}", method = RequestMethod.GET)
    public String diary(@PathVariable("diaryId") Integer diaryId, Model model,String msg) {
        Diary diary=diaryService.selectByPrimaryKey(diaryId);
        int j=0;
        if(diary.getBrowseNum()==null){
            diary.setBrowseNum(0);
            j=1;
        }else{
            j++;
        }
        diary.setBrowseNum(diary.getBrowseNum()+j);
        diaryService.updateBrowseNumByPrimaryKey(diary);
        User user=TokenUtil.getUser();
        if(diary.getImg()!=null) {
            String pictures[] = diary.getImg().split(";");
            if(pictures.length>0) {
               // diary.setImg(pictures[0]);
                model.addAttribute("pictures", pictures);
            }
        }
        //get exchange list for single
        List<Exchange> e=exchangeService.selectExchangeByRestoreId(diaryId);
        List<Exchange> exchanges=new ArrayList<>();
        List<Exchange> replys=new ArrayList<>();
        for (Exchange ex:e) {
            if(ex.getRestoreid()==diaryId){
                if (ex.getReplyid() == null) {
                    exchanges.add(ex);
                } else {
                    replys.add(ex);
                }
            }
        }
        model.addAttribute("exchanges",exchanges);
        model.addAttribute("replys",replys);
        model.addAttribute("user",user);
        model.addAttribute("diary",diary);
        return "umain/single";
    }
    /**
     * 跳转产品列表
     */
    @Autowired
    private ProductService productService;
    @Autowired
    private SiteService siteService;
    @Autowired
    private StyleService styleService;
    @RequestMapping(value = "/product_list", method = RequestMethod.GET)
    public String productList(Model model)  {
        List<Product> products=productService.selectAllProduct();
        for (Product d:products) {
            if(d.getImage()!=null) {
                String arr[] = d.getImage().split(";");
                if (arr[0] != null) {
                    d.setImage(arr[0]);
                }
            }
        }
        List<User> users=userService.selectAllUser();
        List<User>designers=new ArrayList<>();
        for (User user:users) {
            if(user.getRoleId()==2){
                designers.add(user);
            }
        }
        List<Site> sites=siteService.selectAllSite();
        List<Style> styles=styleService.selectAllStyle();
        model.addAttribute("designers",designers);
        model.addAttribute("sites",sites);
        model.addAttribute("styles",styles);
        model.addAttribute("products",products);
        return "umain/product-list";
    }
    /**
     * 根据风格、地点条件查看产品
     */
    /**
     * 跳转产品详情
     */
    @RequestMapping(value = "/product_detail/{productId}", method = RequestMethod.GET)
    public String product(@PathVariable("productId") Integer productId, Model model) {
        Product product=productService.selectByPrimaryKey(productId);
        List<User> designers=userService.selectAllUser();
        if(product.getImage()!=null&&product.getImage().equals("")) {
            String pictures[] = product.getImage().split(";");
            if(pictures.length>0) {
                model.addAttribute("pictures", pictures);
            }
        }
        for (User u:designers) {
            if(u.getUsername().equals(product.getDesignerName())){
                model.addAttribute("designer",u);
            }
        }
        Site site=siteService.selectByPrimaryKey(product.getSiteId());
        Style style=styleService.selectByPrimaryKey(product.getStyleId());
        model.addAttribute("product",product);
        model.addAttribute("site",site);
        model.addAttribute("style",style);
        return "umain/product-detail";
    }
    /**
     * 条件查询
     */
    @RequestMapping(value = "/search", method = RequestMethod.POST)
    public String selectProducts(Model model, HttpServletRequest request) {
        String a=request.getParameter("styleId");
        String b=request.getParameter("siteId");
        String c=request.getParameter("designerName");
        List<Product> p=productService.selectAllProduct();
        List<Product> products=new ArrayList();
        if(a!=""&&b==""&&c==""){
            Integer styleId=Integer.parseInt(a);
            for (Product temp:p) {
                if (temp.getStyleId() == styleId) {
                    products.add(temp);
                }
            }
        } else if(a==""&&b!=""&&c==""){
            Integer siteId=Integer.parseInt(b);
            for (Product temp:p) {
                if (temp.getSiteId() == siteId) {
                    products.add(temp);
                }
            }
        } else if(a==""&&b==""&&c!=""){
            for (Product temp:p) {
                if (temp.getDesignerName().equals(c)) {
                    products.add(temp);
                }
            }
        } else if(a!=""&&b!=""&&c==""){
            Integer styleId=Integer.parseInt(a);
            Integer siteId=Integer.parseInt(b);
            for (Product temp:p) {
                if (temp.getSiteId() == siteId&&temp.getStyleId()==styleId) {
                    products.add(temp);
                }
            }
        } else if(a!=""&&b==""&&c!=""){
            Integer styleId=Integer.parseInt(a);
            for (Product temp:p) {
                if (temp.getDesignerName().equals(c)&&temp.getStyleId()==styleId) {
                    products.add(temp);
                }
            }
        } else if(a==""&&b!=""&&c!=""){
            Integer siteId=Integer.parseInt(b);
            for (Product temp:p) {
                if (temp.getDesignerName().equals(c)&&temp.getSiteId()==siteId) {
                    products.add(temp);
                }
            }
        } else if(a!=""&&b!=""&&c!=""){
            Integer styleId=Integer.parseInt(a);
            Integer siteId=Integer.parseInt(b);
            for (Product temp:p) {
                if (temp.getSiteId() == siteId&&temp.getStyleId()==styleId&&temp.getDesignerName().equals(c)) {
                    products.add(temp);
                }
            }
        } else{
            for (Product temp:p) {
                products.add(temp);
            }
        }
        for (Product temp:products) {
            String arr[] = temp.getImage().split(";");
            if (arr[0] != null) {
                temp.setImage(arr[0]);
            }
        }
        List<User> users=userService.selectAllUser();
        List<User>designers=new ArrayList<>();
        for (User user:users) {
            if(user.getRoleId()==2){
                designers.add(user);
            }
        }
        List<Site> sites=siteService.selectAllSite();
        List<Style> styles=styleService.selectAllStyle();
        model.addAttribute("designers",designers);
        model.addAttribute("sites",sites);
        model.addAttribute("styles",styles);
        model.addAttribute("products",products);
        return "umain/product-list";
    }

    /**
     * 设计师入口查看设计师个人作品
     * @param designerName
     * @param model
     * @return
     */
    @RequestMapping(value = "/hisProduct/{designerName}", method = RequestMethod.GET)
    public String designerProduct(@PathVariable("designerName") String designerName, Model model) {
        List<Product> p=productService.selectAllProduct();
        List<Product> products=new ArrayList();
        for (Product temp:p) {
            if (temp.getDesignerName().equals(designerName)) {
                products.add(temp);
            }
            String arr[] = temp.getImage().split(";");
            if (arr[0] != null) {
                temp.setImage(arr[0]);
            }
        }
        List<User> users=userService.selectAllUser();
        List<User>designers=new ArrayList<>();
        for (User user:users) {
            if(user.getRoleId()==2){
                designers.add(user);
            }
        }
        List<Site> sites=siteService.selectAllSite();
        List<Style> styles=styleService.selectAllStyle();
        model.addAttribute("designers",designers);
        model.addAttribute("sites",sites);
        model.addAttribute("styles",styles);
        model.addAttribute("products",products);
        return "umain/product-list";
    }
}
