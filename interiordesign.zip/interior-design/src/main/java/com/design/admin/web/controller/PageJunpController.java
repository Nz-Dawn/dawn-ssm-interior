package com.design.admin.web.controller;

import com.design.admin.bean.*;
import com.design.admin.service.OrderService;
import com.design.admin.service.SiteService;
import com.design.admin.service.StyleService;
import com.design.admin.service.UserService;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;


/**
 * 页面跳转controller
 */
@Controller
@RequestMapping("/admin/pagejump")
public class PageJunpController {
	
    @Autowired
    private UserService userService;
    @Autowired
    private StyleService styleService;
    @Autowired
    private SiteService siteService;
    @Autowired
    private OrderService orderService;


    /**
     * 跳转到index主页
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/umain", method = RequestMethod.GET)
    public String umain(Model model,String msg) {
        return "jsp/admin/umain/index";
    }


    /**
     * 跳转到index主页
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(Model model,String msg) {
        //获取用户信息
        User user = TokenUtil.getUser();
        Integer userId = user.getId();
        List<List<Permission>> list= userService.selectMenusByUserId(userId);
        //System.out.println(list);
        model.addAttribute("list", list);
        return "index";
    }
    

    /**
     * 跳转到welcome页面
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/welcome", method = RequestMethod.GET)
    public String welcome(HttpServletRequest request,Model model) throws Exception {
        //获取页面所需要的信息
        User user = TokenUtil.getUser();
        if (user.getRoleId() == 1) {
            return "admin-welcome";
        } else if (user.getRoleId() == 2) {
            return "designer-welcome";
        } else {
            //1.设计师的信息
            List<User> userList = userService.selectAllUser();
            List<User> designers = new ArrayList<>();
            for (User u : userList) {
                if (u.getRoleId() == 2) {
                    designers.add(u);
                }
            }
            //2.风格的信息
            List<Style> styles = styleService.selectAllStyle();
            //3.地点信息
            List<Site> sites = siteService.selectAllSite();
            request.setAttribute("styles", styles);
            request.setAttribute("designers", designers);
            model.addAttribute("user", user);
            request.setAttribute("sites", sites);
            return "welcome";
        }
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Order order, Model model) {
        //Date now=new Date();
        //order.setOrderDate(DateTimeUtil.dateToLocalString(now));
        User user=TokenUtil.getUser();
        if(user.getRoleId()==3){
            order.setState(0);
        }
        int add = orderService.insert(order);
        if (add<0) {
            model.addAttribute("msg", "添加预约失败，请重试！");
            return "redirect:/admin/pagejump/welcome?msg=fail";
        } else {
            return "redirect:/admin/pagejump/welcome?msg=success";
        }
    }

    @RequestMapping(value = "/single", method = RequestMethod.GET)
    public String single(Model model) throws Exception {
        return "admin/umain/single";
    }
}
