package com.design.admin.web.controller.admin;

import com.alibaba.fastjson.JSONObject;
import com.design.admin.bean.*;
import com.design.admin.service.DiaryService;
import com.design.util.DateTimeUtil;
import com.design.util.UploadUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping(value = "/admin/user/diary")
public class DiaryController {
    @Autowired
    private DiaryService diaryService;

    /**
     * 跳转到日志列表
     *
     * @return
     */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg, Model model) {
        /*if (msg!=null&&msg!=""){
            model.addAttribute("msg","用户添加成功!");
        }*/
        return "admin/user/diary/list";
    }


    /**
     * 根据条件获取日志列表
     *
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(Diary diary) {
        return diaryService.selectDiaryPage(diary);
    }


    /**
     * 跳转到用户添加页面
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex(Model model) {

        return "admin/user/diary/add";
    }

    /**
     * layedit 图片上传接口
     */
    @PostMapping("/upload")
    @ResponseBody
    public String upload(@Param("file") MultipartFile file, HttpServletRequest request) throws Exception {
        String path = "";
        String imgName = "";
        if (!file.isEmpty()) {
            // 使用UUID生成码给图片重命名，并去掉四个“-”
            imgName = UUID.randomUUID().toString().replaceAll("-", "");
            // 获取文件的扩展名
            String ext = FilenameUtils.getExtension(file.getOriginalFilename());
            // 设置图片上传路径
            String url = request.getSession(true).getServletContext().getRealPath("/") + "upload/images/";
            System.out.println(url);
            // 以绝对路径保存重名命后的图片
            file.transferTo(new File(url + "/" + imgName + "." + ext));
            // 把图片存储路径保存到数据库
            path = "/upload/images/" + imgName + "." + ext;
        }
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> map2 = new HashMap<String, Object>();
        map.put("code", 0);//0表示成功，1失败
        map.put("msg", "上传成功");//提示消息
        map.put("data", map2);
        map2.put("src", path);//图片url
        map2.put("title", imgName);//图片名称，这个会显示在输入框里
        String result = new JSONObject(map).toString();
        return result;
    }

    /**
     * 添加用户---提交
     *
     * @param diary
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Diary diary, Model model,MultipartFile[] file, HttpServletRequest request) throws IOException {
        if(file!=null) {
            String images = UploadUtil.upload(file, request);
            diary.setImg(images);
        }
        int add = diaryService.insert(diary);
        if (add<0) {
            model.addAttribute("msg", "添加日志失败!");
            return "admin/user/diary/add";
        } else {
            return "redirect:/admin/user/diary/index?msg=success";
        }
    }


    /**
     * 跳转到用户修改页面
     *
     * @param diaryId
     * @param model
     * @return
     */
    @RequestMapping(value = "/update/{diaryId}", method = RequestMethod.GET)
    public String updateIndex(@PathVariable("diaryId") Integer diaryId, Model model) {
        Diary diary=diaryService.selectByPrimaryKey(diaryId);
        model.addAttribute("diary", diary);
        return "admin/user/diary/update";
    }


    /**
     * 提交用户修改数据
     *
     * @param diary
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Diary diary,Model model,MultipartFile[] file, HttpServletRequest request) throws IOException {
        Diary d=diaryService.selectByPrimaryKey(diary.getDiaryId());
        if(file!=null) {
            String images = UploadUtil.upload(file, request);
            if(images!=""){
                //String str=d.getImg()+images;
                diary.setImg(images);
            }else{
                String str=d.getImg();
                diary.setImg(str);
            }
        }else {
            String str=d.getImg();
            diary.setImg(str);
        }
        int update=diaryService.updateByPrimaryKey(diary);
        if(update>0){
            model.addAttribute("msg", "日志修改成功!");
            return "redirect:/admin/user/diary/index?msg=success";
        }else{

            model.addAttribute("diary", diary);
            model.addAttribute("msg", "日志更新失败!");
            return "admin/user/diary/update";
        }
    }



//    @ResponseBody
//    @RequestMapping(value = "/updateState",method = RequestMethod.POST)
//    public String updateState(User user) {
//        Integer i=userService.updateStatusById(user);
//        if (i==1) {
//            return "success";
//        }else {
//            return "error";
//        }
//    }


    /**
     * 删除选择日志
     * @param diaryId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteDiaryById",method = RequestMethod.POST)
    public String deleteUserById(Integer diaryId){
        Integer i=diaryService.deleteByPrimaryKey(diaryId);
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
