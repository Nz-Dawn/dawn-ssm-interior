package com.design.admin.web.controller.admin;

import com.design.admin.bean.Exchange;
import com.design.admin.service.ExchangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
@RequestMapping(value = "/admin/exchange")
public class ExchangeController {
    @Autowired
    private ExchangeService exchangeService;

    /**
     * 查看所有评论
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public String selectAllExchange(Exchange exchange, Model model) {
        List<Exchange> exchanges=exchangeService.selectAllExcahnge();
        model.addAttribute("exchanges",exchanges);
        return "";
    }
    /***
     * 发表评论
     * @param exchange
     * @param model
     * @return
     */
    @RequestMapping(value = "/publish", method = RequestMethod.POST)
    public String addIndex(Exchange exchange, Model model) {
        String msg="";
        if(exchange.getRestoreid()==null||exchange.getUsername()==null){
            msg="请完善信息，再发表评论";
            model.addAttribute("msg",msg);
            return "redirect:diaryList/"+exchange.getRestoreid();
        }
        int add=exchangeService.insert(exchange);
        if(add<0){
            msg="发表评论失败，请重试!";
            model.addAttribute("msg",msg);
            return "redirect:diaryList/"+exchange.getRestoreid();
        }
        msg="发表成功!";
        model.addAttribute("msg",msg);
        return "redirect:/diaryList/"+exchange.getRestoreid();
    }

    /**
     * 删除评论
     */
    @RequestMapping(value = "/publish/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable("id") Integer id, Model model) {
        if(id==null){
            return "";
        }else{
            int d=exchangeService.deleteByPrimaryKey(id);
            if(d>0){
                return "删除成功";
            }else{
                return "删除失败";
            }
        }
    }
}
