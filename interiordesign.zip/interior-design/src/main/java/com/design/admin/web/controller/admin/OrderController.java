package com.design.admin.web.controller.admin;


import com.design.admin.bean.Order;
import com.design.admin.bean.PageResult;
import com.design.admin.bean.User;
import com.design.admin.service.OrderService;
import com.design.admin.service.UserService;
import com.design.util.DateTimeUtil;
import com.design.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Controller
@RequestMapping(value = "/admin/order")
public class OrderController {
    @Autowired
    private OrderService orderService;
    @Autowired
    private UserService userService;
    /**
     * 跳转到预约列表
     *
     * @return
     */

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg,Model model) {
        return "admin/order/list";
    }
    /**
     * 根据条件获取用户预约列表
     *
     * @param order
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(Order order) {
        return orderService.selectOrderPage(order);
    }

    /**
     * 跳转到用户添加页面
     *
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex(Model model) {
        User user = TokenUtil.getUser();
        List<User> userList=userService.selectAllUser();
        List<User> designers=new ArrayList<>();
        for (User u:userList) {
            if(u.getRoleId()==2){
                designers.add(u);
            }
        }
        model.addAttribute("user",user);
        model.addAttribute("designers",designers);
        return "admin/order/add";
    }
    /**
     * 添加预约---提交
     *
     * @param order
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Order order, Model model) {
        //Date now=new Date();
        //order.setOrderDate(DateTimeUtil.dateToLocalString(now));
        User user=TokenUtil.getUser();
        if(user.getRoleId()==3&&order.getState()==null){
            order.setState(0);
        }
        int add = orderService.insert(order);
        if (add<0) {
            model.addAttribute("msg", "添加预约失败，请重试！");
            return "admin/order/add";
        } else {
            return "redirect:/admin/order/index?msg=success";
        }
    }

    /**
     * 跳转到用户修改页面
     *
     * @param orderId
     * @param model
     * @return
     */

    @RequestMapping(value = "/update/{orderId}", method = RequestMethod.GET)
    public String updateIndex(@PathVariable("orderId") Integer orderId, Model model) {
        Order order = orderService.selectByPrimaryKey(orderId);
        model.addAttribute("order", order);
        return "admin/order/update";
    }
    /**
     * 提交用户修改数据
     *
     * @param order
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Order order,Model model) {
        int update = orderService.updateByPrimaryKey(order);
        if(update>0){
            model.addAttribute("msg", "修改预约表成功!");
            return "redirect:/admin/order/index?msg=success";
        }else{
            model.addAttribute("order", order);
            model.addAttribute("msg", "修改预约表失败!");
            return "admin/order/update";
        }
    }

    /**
     * 修改用户当前状态
     * @param order
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateState",method = RequestMethod.POST)
    public String updateState(Order order) {
        Integer i=orderService.updateStatusById(order);
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
    /**
     * 删除选择预约表
     * @param order
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteOrderById",method = RequestMethod.POST)
    public String deleteOrderById(Order order){
        Integer i=orderService.deleteByPrimaryKey(order.getOrderId());
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
