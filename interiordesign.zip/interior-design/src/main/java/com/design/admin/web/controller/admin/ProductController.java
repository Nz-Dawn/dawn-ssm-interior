package com.design.admin.web.controller.admin;

import com.design.admin.bean.*;
import com.design.admin.service.ProductService;
import com.design.admin.service.SiteService;
import com.design.admin.service.StyleService;
import com.design.admin.service.UserService;
import com.design.util.TokenUtil;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Controller
@RequestMapping(value = "/admin/product/products")
public class ProductController {
    @Autowired
    private ProductService productService;
    @Autowired
    private SiteService siteService;
    @Autowired
    private StyleService styleService;
    /**
     * 跳转到产品列表
     *
     * @return
     */

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg, Model model) {
        return "admin/product/products/list";
    }
    /**
     * 根据条件获取产品列表
     *
     * @param product
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(Product product) {
        return productService.selectProductPage(product);
    }

    /**
     * 跳转到产品添加页面
     *
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex(Model model) {
        User user = TokenUtil.getUser();
        String username=user.getUsername();
        List<Site> sites=siteService.selectAllSite();
        List<Style> styles=styleService.selectAllStyle();
        model.addAttribute("sites",sites);
        model.addAttribute("styles",styles);
        model.addAttribute("username",username);
        return "admin/product/products/add";
    }
    /**
     * 添加产品---提交
     *
     * @param product
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Product product, Model model,MultipartFile[] images, HttpServletRequest request)  throws IllegalStateException, IOException {
        //定义序号
        int count=1;
        StringBuffer imagesUrl=new StringBuffer();
        for (MultipartFile mf : images) {
            if(!mf.isEmpty()){
                // 使用UUID给图片重命名，并去掉四个“-”
                String name = UUID.randomUUID().toString().replaceAll("-", "");
                // 获取文件的扩展名
                String ext = FilenameUtils.getExtension(mf.getOriginalFilename());
                // 设置图片上传路径
                String url = request.getSession(true).getServletContext().getRealPath("/")+"upload/images/";
                System.out.println(url);
                // 以绝对路径保存重名命后的图片
                mf.transferTo(new File(url + "/" + name + "." + ext));
                // 把图片存储路径保存到数据库
                String path="upload/images/" + name + "." + ext;
                imagesUrl.append(path);
                imagesUrl.append(";");
            }
            count++;
        }
        //去除最后一个;号

        if(images==null){
            Product p=productService.selectByPrimaryKey(product.getProductId());
            product.setImage(p.getImage());
        }
        String s=imagesUrl.substring(0, imagesUrl.length()-1);
        if(imagesUrl!=null) {
            product.setImage(s);
        }
        int add = productService.insert(product);
        if (add<0) {
            model.addAttribute("msg", "添加产品失败，请重试！");
            return "admin/product/products/add";
        } else {
            return "redirect:/admin/product/products/index?msg=success";
        }
    }

    /**
     * 跳转到产品修改页面
     *
     * @param productId
     * @param model
     * @return
     */

    @Autowired private UserService userService;
    @RequestMapping(value = "/preview/{productId}", method = RequestMethod.GET)
    public String checkProduct(@PathVariable("productId") Integer productId, Model model) {
        Product product=productService.selectByPrimaryKey(productId);
        Site site=siteService.selectByPrimaryKey(product.getSiteId());
        Style style=styleService.selectByPrimaryKey(product.getStyleId());
        String img=product.getImage();
        if(img!=null||img!="") {
            String images[] = img.split(";");
            List<String> image=new ArrayList<>();
            for (String str:images) {
                image.add(str);
            }
            model.addAttribute("image",image);
        }
        List<User> users=userService.selectAllUser();
        for (User user:users) {
            if(user.getUsername().equals(product.getDesignerName())){
                model.addAttribute("designer",user);
            }
        }
        model.addAttribute("site",site);
        model.addAttribute("style",style);
        model.addAttribute("product", product);
        return "admin/product/products/detail";
    }
    /**
     * 提交产品修改数据
     *
     * @param product
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Product product,Model model,MultipartFile[] images, HttpServletRequest request)throws IllegalStateException, IOException {
        //定义序号
        int count=1;
        StringBuffer imgUrl=new StringBuffer();
        if(!images[0].isEmpty()) {
            for (MultipartFile mf : images) {
                if (!mf.isEmpty()) {
                    // 使用UUID给图片重命名，并去掉四个“-”
                    String name = UUID.randomUUID().toString().replaceAll("-", "");
                    // 获取文件的扩展名
                    String ext = FilenameUtils.getExtension(mf.getOriginalFilename());
                    // 设置图片上传路径
                    String url = request.getSession(true).getServletContext().getRealPath("/") + "upload/images/";
                    System.out.println(url);
                    // 以绝对路径保存重名命后的图片
                    mf.transferTo(new File(url + "/" + name + "." + ext));
                    // 把图片存储路径保存到数据库
                    String path = "upload/images/" + name + "." + ext;
                    imgUrl.append(path);
                    imgUrl.append(";");
                }
                count++;
            }
            String s = imgUrl.substring(0, imgUrl.length() - 1);
            //去除最后一个;号
            if(s!="") {
                product.setImage(s);
            }
        } else{
            String ss=productService.selectByPrimaryKey(product.getProductId()).getImage();
            product.setImage(ss);
        }
        int update = productService.updateByPrimaryKey(product);
        if(update>0){
            model.addAttribute("msg", "修改产品成功!");
            return "redirect:/admin/product/products/index?msg=success";
        }else{
            model.addAttribute("product", product);
            model.addAttribute("msg", "修改产品失败!");
            return "admin/product/products/update";
        }
    }

    /**
     * 查看产品详情
     */
    @RequestMapping(value = "/update/{productId}", method = RequestMethod.GET)
    public String updateIndex(@PathVariable("productId") Integer productId, Model model) {
        Product product=productService.selectByPrimaryKey(productId);
        List<Site> sites=siteService.selectAllSite();
        List<Style> styles=styleService.selectAllStyle();
        model.addAttribute("sites",sites);
        model.addAttribute("styles",styles);
        model.addAttribute("product", product);
        return "admin/product/products/update";
    }
    /**
     * 修改产品当前状态
     * @param product
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateState",method = RequestMethod.POST)
    public String updateState(Product product) {
        Integer i=productService.updateStatusById(product);
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
    /**
     * 删除选择产品
     * @param product
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteProductById",method = RequestMethod.POST)
    public String deleteProductById(Product product){
        Integer i=productService.deleteByPrimaryKey(product.getProductId());
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
