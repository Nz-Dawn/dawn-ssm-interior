package com.design.admin.web.controller.admin;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Site;
import com.design.admin.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/admin/product/site")
public class SiteController {
    @Autowired
    private SiteService siteService;
    /**
     * 跳转到地点列表
     *
     * @return
     */

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg, Model model) {
        return "admin/product/site/list";
    }
    /**
     * 根据条件查找地点
     *
     * @param site
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(Site site) {
        return siteService.selectSitePage(site);
    }

    /**
     * 跳转到地点添加页面
     *
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex() {
        return "admin/product/site/add";
    }
    /**
     * 添加地点---提交
     *
     * @param site
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Site site, Model model) {
        int add = siteService.insert(site);
        if (add<0) {
            model.addAttribute("msg", "添加预约失败，请重试！");
            return "admin/product/site/add";
        } else {
            return "redirect:/admin/product/site/index?msg=success";
        }
    }

    /**
     * 跳转到地点修改页面
     *
     * @param siteId
     * @param model
     * @return
     */
    @RequestMapping(value = "/update/{siteId}", method = RequestMethod.GET)
    public String updateIndex(@PathVariable("siteId") Integer siteId, Model model) {
        Site site = siteService.selectByPrimaryKey(siteId);
        model.addAttribute("site", site);
        return "admin/product/site/update";
    }
    /**
     * 提交用户修改数据
     *
     * @param site
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Site site,Model model) {
        int update = siteService.updateByPrimaryKey(site);
        if(update>0){
            model.addAttribute("msg", "修改预约表成功!");
            return "redirect:/admin/product/site/index?msg=success";
        }else{
            model.addAttribute("site", site);
            model.addAttribute("msg", "用户失败成功!");
            return "admin/product/site/update";
        }
    }

    /**
     * 删除选择预约表
     * @param site
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteSiteById",method = RequestMethod.POST)
    public String deleteOrderById(Site site){
        Integer i=siteService.deleteByPrimaryKey(site.getSiteId());
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
