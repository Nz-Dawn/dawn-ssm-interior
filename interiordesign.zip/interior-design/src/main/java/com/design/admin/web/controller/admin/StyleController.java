package com.design.admin.web.controller.admin;

import com.design.admin.bean.PageResult;
import com.design.admin.bean.Style;
import com.design.admin.service.StyleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/admin/product/style")
public class StyleController {
    @Autowired
    private StyleService styleService;
    /**
     * 跳转到风格列表
     *
     * @return
     */

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg, Model model) {
        return "admin/product/style/list";
    }
    /**
     * 根据条件查找风格
     *
     * @param style
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(Style style) {
        return styleService.selectStylePage(style);
    }

    /**
     * 跳转到风格添加页面
     *
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex() {
        return "admin/product/style/add";
    }
    /**
     * 添加风格---提交
     *
     * @param style
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(Style style, Model model) {
        int add = styleService.insert(style);
        if (add<0) {
            model.addAttribute("msg", "添加风格失败，请重试！");
            return "admin/product/style/add";
        } else {
            return "redirect:/admin/product/style/index?msg=success";
        }
    }

    /**
     * 跳转到风格修改页面
     *
     * @param styleId
     * @param model
     * @return
     */
    @RequestMapping(value = "/update/{styleId}", method = RequestMethod.GET)
    public String updateIndex(@PathVariable("styleId") Integer styleId, Model model) {
        Style style = styleService.selectByPrimaryKey(styleId);
        model.addAttribute("style", style);
        return "admin/product/style/update";
    }
    /**
     * 提交用户修改数据
     *
     * @param style
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Style style,Model model) {
        int update = styleService.updateByPrimaryKey(style);
        if(update>0){
            model.addAttribute("msg", "修改预约表成功!");
            return "redirect:/admin/product/style/index?msg=success";
        }else{
            model.addAttribute("style", style);
            model.addAttribute("msg", "用户失败成功!");
            return "admin/product/style/update";
        }
    }

    /**
     * 删除选择风格表
     * @param style
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteStyleById",method = RequestMethod.POST)
    public String deleteStyleById(Style style){
        Integer i=styleService.deleteByPrimaryKey(style.getStyleId());
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
