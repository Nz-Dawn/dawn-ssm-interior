package com.design.admin.web.controller.admin;

import com.design.admin.bean.Dept;
import com.design.admin.bean.PageResult;
import com.design.admin.bean.Role;
import com.design.admin.bean.User;
import com.design.admin.service.DeptService;
import com.design.admin.service.RoleService;
import com.design.admin.service.UserService;
import com.design.util.TokenUtil;
import com.design.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;


@Controller
@RequestMapping(value = "/admin/user")
public class UserController {
	
    @Autowired
    private UserService userService;
    
    @Autowired
    private DeptService deptService;
    
    @Autowired
    private RoleService roleService;
    

    /**
     * 跳转到用户列表
     *
     * @return
     */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(String msg,Model model) {
        /*if (msg!=null&&msg!=""){
            model.addAttribute("msg","用户添加成功!");
        }*/
        return "admin/user/list";
    }
    

    /**
     * 根据条件获取用户列表
     *
     * @param user
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public PageResult list(User user) {
        return userService.selectUserPage(user);
    }

    
    /**
     * 跳转到用户添加页面
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndex(Model model) {
        List<Dept> depts = deptService.selectDepts();
        List<Role> roles = roleService.selectRoles();

        model.addAttribute("depts", depts);
        model.addAttribute("roles", roles);
        return "admin/user/add";
    }

    
    /**
     * 添加用户---提交
     *
     * @param user
     * @param model
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(User user, Model model,MultipartFile inputImage[], HttpServletRequest request) throws IOException {
        StringBuffer images=new StringBuffer();
        if(!inputImage[0].isEmpty()){
            String image = UploadUtil.upload(inputImage, request);
            //images.append(image);
            image="/"+image;
            user.setImages(image);
        }
        User add = userService.add(user);
        if (add.getUsername() == null) {
            List<Dept> depts = deptService.selectDepts();
            List<Role> roles = roleService.selectRoles();
            model.addAttribute("depts", depts);
            model.addAttribute("roles", roles);
            model.addAttribute("user", user);
            model.addAttribute("msg", "登录已存在,请修改登录名!");
            return "admin/user/add";
        } else {
            return "redirect:/admin/user/index?msg=success";
        }
    }
    

    /**
     * 跳转到用户修改页面
     *
     * @param userId
     * @param model
     * @return
     */
    @RequestMapping(value = "/update/{userId}", method = RequestMethod.GET)
    public String updateInex(@PathVariable("userId") Integer userId, Model model) {
        User user = userService.selectUserById(userId);
        List<Dept> depts = deptService.selectDepts();
        List<Role> roles = roleService.selectRoles();
        model.addAttribute("depts", depts);
        model.addAttribute("roles", roles);
        model.addAttribute("user", user);
        return "admin/user/update";
    }

    
    /**
     * 提交用户修改数据
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(User user,Model model,MultipartFile inputImage[], HttpServletRequest request) throws IOException {
        StringBuffer images=new StringBuffer();
        if(!inputImage[0].isEmpty()){
            String image = UploadUtil.upload(inputImage, request);
            //images.append(image);
            image="/"+image;
            user.setImages(image);
        }else {
            User u=userService.selectUserById(user.getUserId());
            if(u.getImages()!=null)
                user.setImages(u.getImages());
        }
        User update = userService.update(user);
        if(update!=null){
            User u= TokenUtil.getUser();
            model.addAttribute("msg", "用户修改成功!");
            if(u.getRoleId()==1) {
                return "redirect:/admin/user/index?msg=success";
            }else{
                return "redirect:/admin/member/index";
            }
        }else{
            List<Dept> depts = deptService.selectDepts();
            List<Role> roles = roleService.selectRoles();
            model.addAttribute("depts", depts);
            model.addAttribute("roles", roles);
            model.addAttribute("user", user);
            model.addAttribute("msg", "用户失败成功!");
            return "admin/user/update";
        }
    }

    @ResponseBody
    @RequestMapping(value = "/uploadImg", method = RequestMethod.POST)
    public String uploadImg(User user, Model model, MultipartFile inputImage[], HttpServletRequest request) throws IOException {
        String images="";
        if(inputImage!=null) {
            images = UploadUtil.upload(inputImage, request);
        }
            return images;
    }

    /**
     * 修改用户当前状态
     * @param user
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateState",method = RequestMethod.POST)
    public String updateState(User user) {
        Integer i=userService.updateStatusById(user);
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
    

    /**
     * 删除选择用户
     * @param user
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/deleteUserById",method = RequestMethod.POST)
    public String deleteUserById(User user){
        Integer i=userService.deleteUserById(user);
        if (i==1) {
            return "success";
        }else {
            return "error";
        }
    }
}
