package com.design.util;

import com.design.admin.bean.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;

/**
 * @desc Shiro管理下的Token工具类
 */
public class TokenUtil {
	
    /**
     * 登录
     *
     * @param user
     * @param user
     * @param rememberMe @return
     */
    public static User login(User user, boolean rememberMe) {
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(user.getUsername(), user.getPassword());
        token.setRememberMe(rememberMe);
        subject.login(token);
        return getUser();
    }

    /**
     * 获取当前登录的用户User对象
     *
     * @return
     */
    public static User getUser() {
        return (User) SecurityUtils.getSubject().getPrincipal();
    }
}
