package com.design.util;

import org.apache.commons.io.FilenameUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class UploadUtil {
    public static String upload(MultipartFile[] images, HttpServletRequest request) throws IOException {
        int count=1;
        StringBuffer imagesUrl=new StringBuffer();
        for (MultipartFile mf : images) {
            if(!mf.isEmpty()){
                // 使用UUID给图片重命名，并去掉四个“-”
                String name = UUID.randomUUID().toString().replaceAll("-", "");
                // 获取文件的扩展名
                String ext = FilenameUtils.getExtension(mf.getOriginalFilename());
                // 设置图片上传路径
                String url = request.getSession(true).getServletContext().getRealPath("/")+"upload/images/";
                System.out.println(url);
                // 以绝对路径保存重名命后的图片
                mf.transferTo(new File(url + "/" + name + "." + ext));
                // 把图片存储路径保存到数据库
                String path="upload/images/" + name + "." + ext;
                imagesUrl.append(path);
                imagesUrl.append(";");
            }
            count++;
        }
        String s=imagesUrl.substring(0,imagesUrl.length()-1);
        return s;
    }
}
